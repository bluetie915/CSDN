package com.zhang;

public interface SellingRule {
    int reducePrice(Book book);
}
