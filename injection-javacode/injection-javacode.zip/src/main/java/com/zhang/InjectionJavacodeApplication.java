package com.zhang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;

@SpringBootApplication
public class InjectionJavacodeApplication {

    public static void main(String[] args) {
        ApplicationContext container = SpringApplication.run(InjectionJavacodeApplication.class, args);
        TaobaoSell sell = container.getBean(TaobaoSell.class);

        List<Book> bookList1 = sell.findBookByPublisher("清华大学出版社");
        for (Book book : bookList1) {
            System.out.println(book);
        }
        Book book = bookList1.get(1);
        int priceBefore = book.getPrice();
        int priceAfter = sell.sellingRuleDiscount(book);
        System.out.println(book.getName() + ",该书打折前价格为：" + priceBefore);
        System.out.println(book.getName() + ",该书打折后价格为：" + priceAfter);
    }
}
