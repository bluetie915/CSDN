package com.zhang;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

//按照类型查找书籍，此时书在文件中
public class FindByType implements BookFinder {
    @Override
    public List<Book> findBooks(String type) {
        List<Book> bookList = new ArrayList<>();
        try {
            // UTF-8
            List<String> lines = Files.readAllLines(Paths.get("book.txt"));
            return lines.stream().map(line -> {
                String bookName = line.split(",")[0];
                String bookPublisher = line.split(",")[1];
                String bookType = line.split(",")[2];
                int bookPrice = Integer.parseInt(line.split(",")[3]);
                return new Book(bookName, bookPublisher, bookType, bookPrice);
            }).filter(book -> book.getType().equals(type)).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }
}
