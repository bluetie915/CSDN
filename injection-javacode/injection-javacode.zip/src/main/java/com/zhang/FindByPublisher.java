package com.zhang;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

//按照出版社查找书籍，此时书在构造方法中
public class FindByPublisher implements BookFinder {
    private List<Book> bookList = null;
    public FindByPublisher() {
        bookList = new ArrayList<>();
        bookList.add(new Book("安徒生童话", "中国人民教育出版社", "儿童书籍", 38));
        bookList.add(new Book("一千零一夜", "清华大学出版社", "儿童书籍", 26));
        bookList.add(new Book("安徒生童话", "山西少年宫出版社", "儿童书籍", 64));

        bookList.add(new Book("操作系统", "清华大学出版社", "程序员书籍", 88));
        bookList.add(new Book("java程序基础", "天津科教出版社", "程序员书籍", 36));
        bookList.add(new Book("数据库原理及理论", "高等教育出版社", "程序员书籍", 78));

        bookList.add(new Book("中国近现代史纲要", "清华大学出版社", "政治书籍", 60));
        bookList.add(new Book("思想道德修养与法律基础", "高等教育出版社", "政治书籍", 98));
    }
    @Override
    public List<Book> findBooks(String publisher) {
        return bookList.stream().
                filter(book -> book.getPublisher().equals(publisher))
                .collect(Collectors.toList());
    }
}
