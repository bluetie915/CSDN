package com.zhang;

import java.util.List;

public class TaobaoSell {

    private BookFinder bookFinder;
    private SellingRule sellingRule;

    public TaobaoSell(BookFinder bookFinder, SellingRule sellingRule) {
        this.bookFinder = bookFinder;
        this.sellingRule = sellingRule;
    }

    List<Book> findBookByPublisher(String publisher){
        return bookFinder.findBooks(publisher);
    }

    List<Book> findBookByType(String type){
        return bookFinder.findBooks(type);
    }

    int sellingRuleDiscount(Book book){
        return sellingRule.reducePrice(book);
    }

    int sellingRuleReduce(Book book){
        return sellingRule.reducePrice(book);
    }
}
