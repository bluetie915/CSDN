package com.zhang;

import java.util.List;

public interface BookFinder {
    List<Book> findBooks(String parameter);
}
