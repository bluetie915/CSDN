package com.zhang;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class AppConfiguration {
    @Bean("byPublisher")
    public BookFinder findByPublisher(){
        return new FindByPublisher();
    }
    @Bean
    public BookFinder findByType(){
        return new FindByType();
    }
    @Bean
    public SellingRule sellingRuleDiscount(){
        return new SellingRuleDiscount();
    }
    @Bean
    public SellingRule sellingRuleReduce(){
        return new SellingRuleReduce();
    }
    @Bean
    public TaobaoSell taobaoSell(@Qualifier("byPublisher") BookFinder bookFinder, @Qualifier("sellingRuleReduce") SellingRule sellingRule){
        return new TaobaoSell(bookFinder,sellingRule);
    }
}
