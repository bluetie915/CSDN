package com.zhang;

//折扣，满70打八折
public class SellingRuleDiscount implements SellingRule {
    @Override
    public int reducePrice(Book book) {
        if (book.getPrice() > 70)
            return (int) (book.getPrice() * 0.8);
        return book.getPrice();
    }
}
