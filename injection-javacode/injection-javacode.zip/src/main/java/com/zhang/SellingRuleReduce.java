package com.zhang;

//优惠，满70减10块
public class SellingRuleReduce implements SellingRule {
    @Override
    public int reducePrice(Book book) {
        if (book.getPrice() > 70)
            return book.getPrice() - 10;
        return book.getPrice();
    }
}
